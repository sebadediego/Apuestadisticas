'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';

const AFFILIATE_LINK = 'https://lkpq.cc/b8edf9';

const navItems = [
  { href: '/', label: 'Inicio', icon: 'home' },
  { href: '/partidos', label: 'Partidos', icon: 'calendar' },
  { href: '/en-vivo', label: 'En Vivo', icon: 'live' },
  { href: '/cuotas', label: 'Cuotas', icon: 'odds' },
  { href: '/menu', label: 'Menú', icon: 'menu' },
];

const desktopNavItems = [
  { href: '/', label: 'Inicio' },
  { href: '/partidos', label: 'Partidos' },
  { href: '/en-vivo', label: 'En Vivo' },
  { href: '/cuotas', label: 'Cuotas' },
  { href: '/predicciones', label: 'Predicciones' },
  { href: '/lesiones', label: 'Lesiones' },
  { href: '/asistente', label: 'Asistente IA' },
];

function NavIcon({ name, className }: { name: string; className?: string }) {
  const cn = className || '';
  switch (name) {
    case 'home':
      return (
        <svg className={cn} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
          <polyline points="9 22 9 12 15 12 15 22" />
        </svg>
      );
    case 'calendar':
      return (
        <svg className={cn} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <rect width="18" height="18" x="3" y="4" rx="2" ry="2" />
          <line x1="16" x2="16" y1="2" y2="6" />
          <line x1="8" x2="8" y1="2" y2="6" />
          <line x1="3" x2="21" y1="10" y2="10" />
        </svg>
      );
    case 'live':
      return (
        <svg className={cn} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="2" />
          <path d="M16.24 7.76a6 6 0 0 1 0 8.49" />
          <path d="M7.76 16.24a6 6 0 0 1 0-8.49" />
          <path d="M19.07 4.93a10 10 0 0 1 0 14.14" />
          <path d="M4.93 19.07a10 10 0 0 1 0-14.14" />
        </svg>
      );
    case 'odds':
      return (
        <svg className={cn} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="12" x2="12" y1="20" y2="10" />
          <line x1="18" x2="18" y1="20" y2="4" />
          <line x1="6" x2="6" y1="20" y2="16" />
        </svg>
      );
    case 'menu':
      return (
        <svg className={cn} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <line x1="4" x2="20" y1="12" y2="12" />
          <line x1="4" x2="20" y1="6" y2="6" />
          <line x1="4" x2="20" y1="18" y2="18" />
        </svg>
      );
    default:
      return null;
  }
}

export default function Navbar() {
  const pathname = usePathname();

  return (
    <>
      {/* Desktop Top Navbar */}
      <nav className="navbar-desktop">
        <Link href="/" className="navbar-logo">
          APUESTA<span>DISTICAS</span>
        </Link>

        <div className="navbar-links">
          {desktopNavItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`navbar-link ${pathname === item.href ? 'active' : ''}`}
            >
              {item.label}
            </Link>
          ))}
        </div>

        <a
          href={AFFILIATE_LINK}
          target="_blank"
          rel="noopener noreferrer"
          className="navbar-cta"
        >
          Ir a 1Win →
        </a>
      </nav>

      {/* Mobile Bottom Tab Bar */}
      <nav className="bottom-bar">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href === '/menu' ? '/predicciones' : item.href}
            className={`bottom-tab ${pathname === item.href ? 'active' : ''}`}
          >
            <NavIcon name={item.icon} />
            {item.icon === 'live' && <span className="live-dot" />}
            <span>{item.label}</span>
          </Link>
        ))}
      </nav>
    </>
  );
}
