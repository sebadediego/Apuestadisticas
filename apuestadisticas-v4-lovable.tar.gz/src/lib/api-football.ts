// src/lib/api-football.ts
// Core library for API-Football (API-Sports) integration

const API_KEY = process.env.API_FOOTBALL_KEY || '';
const API_HOST = process.env.API_FOOTBALL_HOST || 'v3.football.api-sports.io';
const BASE_URL = `https://${API_HOST}`;

interface ApiResponse<T> {
  get: string;
  parameters: Record<string, string>;
  errors: Record<string, string> | string[];
  results: number;
  paging: { current: number; total: number };
  response: T;
}

async function fetchApi<T>(endpoint: string, params?: Record<string, string | number>): Promise<ApiResponse<T>> {
  const url = new URL(`${BASE_URL}${endpoint}`);
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') {
        url.searchParams.append(key, String(value));
      }
    });
  }

  const res = await fetch(url.toString(), {
    headers: {
      'x-apisports-key': API_KEY,
      'x-apisports-host': API_HOST,
    },
    next: { revalidate: 120 }, // Cache for 2 minutes
  });

  if (!res.ok) {
    throw new Error(`API-Football error: ${res.status} ${res.statusText}`);
  }

  return res.json();
}

// ==================== COUNTRIES ====================
export async function getCountries() {
  return fetchApi<any[]>('/countries');
}

// ==================== SEASONS ====================
export async function getSeasons() {
  return fetchApi<number[]>('/leagues/seasons');
}

// ==================== LEAGUES ====================
export async function getLeagues(params?: { id?: number; country?: string; season?: number; current?: string }) {
  return fetchApi<any[]>('/leagues', params as any);
}

// ==================== STANDINGS ====================
export async function getStandings(params: { league: number; season: number }) {
  return fetchApi<any[]>('/standings', params as any);
}

// ==================== TEAMS ====================
export async function getTeams(params?: { id?: number; league?: number; season?: number; country?: string }) {
  return fetchApi<any[]>('/teams', params as any);
}

export async function getTeamStatistics(params: { team: number; league: number; season: number }) {
  return fetchApi<any>('/teams/statistics', params as any);
}

// ==================== FIXTURES ====================
export async function getFixtures(params?: {
  id?: number; live?: string; date?: string; league?: number;
  season?: number; team?: number; from?: string; to?: string;
  status?: string; timezone?: string;
}) {
  return fetchApi<any[]>('/fixtures', { timezone: 'America/Argentina/Buenos_Aires', ...params } as any);
}

export async function getFixturesToday() {
  const today = new Date().toISOString().split('T')[0];
  return getFixtures({ date: today });
}

export async function getLiveFixtures() {
  return fetchApi<any[]>('/fixtures', { live: 'all', timezone: 'America/Argentina/Buenos_Aires' } as any);
}

// ==================== HEAD TO HEAD ====================
export async function getHeadToHead(params: { h2h: string; last?: number }) {
  return fetchApi<any[]>('/fixtures/headtohead', params as any);
}

// ==================== EVENTS ====================
export async function getFixtureEvents(fixtureId: number) {
  return fetchApi<any[]>('/fixtures/events', { fixture: fixtureId } as any);
}

// ==================== LINEUPS ====================
export async function getFixtureLineups(fixtureId: number) {
  return fetchApi<any[]>('/fixtures/lineups', { fixture: fixtureId } as any);
}

// ==================== STATISTICS ====================
export async function getFixtureStatistics(fixtureId: number) {
  return fetchApi<any[]>('/fixtures/statistics', { fixture: fixtureId } as any);
}

// ==================== PLAYERS ====================
export async function getPlayers(params?: { id?: number; team?: number; league?: number; season?: number; page?: number }) {
  return fetchApi<any[]>('/players', params as any);
}

export async function getTopScorers(params: { league: number; season: number }) {
  return fetchApi<any[]>('/players/topscorers', params as any);
}

// ==================== TRANSFERS ====================
export async function getTransfers(params: { player?: number; team?: number }) {
  return fetchApi<any[]>('/transfers', params as any);
}

// ==================== TROPHIES ====================
export async function getTrophies(params: { player?: number; coach?: number }) {
  return fetchApi<any[]>('/trophies', params as any);
}

// ==================== INJURIES ====================
export async function getInjuries(params?: { league?: number; season?: number; fixture?: number; team?: number }) {
  return fetchApi<any[]>('/injuries', params as any);
}

// ==================== ODDS ====================
export async function getOdds(params?: { fixture?: number; league?: number; season?: number; bookmaker?: number; date?: string }) {
  return fetchApi<any[]>('/odds', params as any);
}

export async function getLiveOdds(params?: { fixture?: number }) {
  return fetchApi<any[]>('/odds/live', params as any);
}

// ==================== PREDICTIONS ====================
export async function getPredictions(fixtureId: number) {
  return fetchApi<any[]>('/predictions', { fixture: fixtureId } as any);
}

// ==================== HELPERS ====================
export function getTodayDate(): string {
  return new Date().toISOString().split('T')[0];
}

export function getCurrentSeason(): number {
  const now = new Date();
  return now.getMonth() >= 6 ? now.getFullYear() : now.getFullYear() - 1;
}

// Top leagues for default views
export const TOP_LEAGUES = [
  { id: 128, name: 'Liga Profesional Argentina', country: 'Argentina', flag: '🇦🇷' },
  { id: 39, name: 'Premier League', country: 'England', flag: '🏴󠁧󠁢󠁥󠁮󠁧󠁿' },
  { id: 140, name: 'La Liga', country: 'Spain', flag: '🇪🇸' },
  { id: 135, name: 'Serie A', country: 'Italy', flag: '🇮🇹' },
  { id: 78, name: 'Bundesliga', country: 'Germany', flag: '🇩🇪' },
  { id: 61, name: 'Ligue 1', country: 'France', flag: '🇫🇷' },
  { id: 2, name: 'Champions League', country: 'World', flag: '🏆' },
  { id: 13, name: 'Copa Libertadores', country: 'World', flag: '🏆' },
  { id: 71, name: 'Copa Sudamericana', country: 'World', flag: '🏆' },
];

// Status mapping for fixtures
export const FIXTURE_STATUS: Record<string, { label: string; color: string; live: boolean }> = {
  TBD: { label: 'Por definir', color: 'text-text-muted', live: false },
  NS: { label: 'No iniciado', color: 'text-text-secondary', live: false },
  '1H': { label: '1er Tiempo', color: 'text-accent-emerald', live: true },
  HT: { label: 'Entretiempo', color: 'text-accent-amber', live: true },
  '2H': { label: '2do Tiempo', color: 'text-accent-emerald', live: true },
  ET: { label: 'Tiempo Extra', color: 'text-accent-amber', live: true },
  BT: { label: 'Descanso TE', color: 'text-accent-amber', live: true },
  P: { label: 'Penales', color: 'text-accent-red', live: true },
  SUSP: { label: 'Suspendido', color: 'text-accent-red', live: false },
  INT: { label: 'Interrumpido', color: 'text-accent-red', live: false },
  FT: { label: 'Finalizado', color: 'text-text-muted', live: false },
  AET: { label: 'Final TE', color: 'text-text-muted', live: false },
  PEN: { label: 'Final Penales', color: 'text-text-muted', live: false },
  PST: { label: 'Pospuesto', color: 'text-accent-amber', live: false },
  CANC: { label: 'Cancelado', color: 'text-accent-red', live: false },
  ABD: { label: 'Abandonado', color: 'text-accent-red', live: false },
  AWD: { label: 'Otorgado', color: 'text-text-muted', live: false },
  WO: { label: 'Walkover', color: 'text-text-muted', live: false },
  LIVE: { label: 'En Vivo', color: 'text-accent-emerald', live: true },
};
