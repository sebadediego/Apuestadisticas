import { getFixtures, getOdds } from '@/lib/api-football';
import PartidosClient from './PartidosClient';

// TOP_LEAGUES for filter dropdown
const TOP_LEAGUES = [
  { id: 39, name: 'Premier League', country: 'England' },
  { id: 140, name: 'La Liga', country: 'Spain' },
  { id: 135, name: 'Serie A', country: 'Italy' },
  { id: 78, name: 'Bundesliga', country: 'Germany' },
  { id: 61, name: 'Ligue 1', country: 'France' },
  { id: 2, name: 'Champions League', country: 'Europe' },
  { id: 3, name: 'Europa League', country: 'Europe' },
  { id: 128, name: 'Liga Profesional Argentina', country: 'Argentina' },
  { id: 130, name: 'Copa Argentina', country: 'Argentina' },
  { id: 13, name: 'Copa Libertadores', country: 'South America' },
];

function getTodayDate() {
  return new Date().toISOString().split('T')[0];
}

// ====================================================================
// BUG FIX: searchParams must be properly awaited and parsed.
// The league filter was failing because:
// 1. searchParams.league was not being parsed as a number
// 2. When filtering by league, we need to pass it directly to the API
// ====================================================================
interface PageProps {
  searchParams: Promise<{ league?: string; date?: string }>;
}

export default async function PartidosPage({ searchParams }: PageProps) {
  // In Next.js 14+, searchParams is a Promise — MUST await it
  const params = await searchParams;
  
  const date = params.date || getTodayDate();
  
  // BUG FIX: Parse league as number, ensure it's valid
  const leagueParam = params.league;
  const leagueId = leagueParam ? parseInt(leagueParam, 10) : undefined;
  const validLeagueId = leagueId && !isNaN(leagueId) ? leagueId : undefined;

  let fixtures: any[] = [];
  try {
    // BUG FIX: Pass league ID directly to API when filtering
    const fetchParams: any = { date };
    if (validLeagueId) {
      fetchParams.league = validLeagueId;
    }
    const res = await getFixtures(fetchParams);
    fixtures = res.response || [];
  } catch (e) {
    console.error('Error fetching fixtures:', e);
  }

  // Group by league (same logic as home)
  const grouped: Record<number, { league: any; fixtures: any[] }> = {};
  for (const fix of fixtures) {
    const lid = fix.league?.id;
    if (!lid) continue;
    if (!grouped[lid]) {
      grouped[lid] = { league: fix.league, fixtures: [] };
    }
    grouped[lid].fixtures.push(fix);
  }

  const sortedLeagues = Object.entries(grouped)
    .sort(([, a], [, b]) =>
      (a.league?.name || '').localeCompare(b.league?.name || '')
    )
    .map(([id, data]) => ({ id: Number(id), ...data }));

  // Fetch odds
  let oddsMap: Record<number, { home: string | null; draw: string | null; away: string | null }> = {};
  try {
    const oddsRaw = await getOdds({ date });
    const oddsRes = oddsRaw.response || []; if (Array.isArray(oddsRes)) {
      for (const item of oddsRes) {
        const fid = item.fixture?.id;
        if (!fid) continue;
        for (const bk of (item.bookmakers || [])) {
          const market = bk.bets?.find((b: any) => b.id === 1 || b.name === 'Match Winner');
          if (market) {
            oddsMap[fid] = {
              home: market.values?.find((v: any) => v.value === 'Home')?.odd || null,
              draw: market.values?.find((v: any) => v.value === 'Draw')?.odd || null,
              away: market.values?.find((v: any) => v.value === 'Away')?.odd || null,
            };
            break;
          }
        }
      }
    }
  } catch (e) {
    console.error('Error fetching odds:', e);
  }

  return (
    <PartidosClient
      leagues={sortedLeagues}
      oddsMap={oddsMap}
      topLeagues={TOP_LEAGUES}
      currentDate={date}
      currentLeague={validLeagueId || null}
    />
  );
}
