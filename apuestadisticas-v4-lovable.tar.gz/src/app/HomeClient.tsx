'use client';

import LeagueAccordion from '@/components/LeagueAccordion';
import Banner1Win from '@/components/Banner1Win';

interface LeagueData {
  id: number;
  league: any;
  fixtures: any[];
}

interface HomeClientProps {
  leagues: LeagueData[];
  oddsMap: Record<number, { home: string | null; draw: string | null; away: string | null }>;
  topLeagueIds: number[];
}

export default function HomeClient({ leagues, oddsMap, topLeagueIds }: HomeClientProps) {
  return (
    <div className="layout-with-sidebar">
      <div className="layout-main">
        {/* Top 1Win Banner */}
        <Banner1Win variant="full" />

        <div className="page-header">
          <h1 className="page-title">Partidos de hoy</h1>
        </div>

        {leagues.length === 0 ? (
          <div className="empty-state">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
              <circle cx="12" cy="12" r="10" />
              <path d="m15 9-6 6M9 9l6 6" />
            </svg>
            <p>No hay partidos programados para hoy</p>
          </div>
        ) : (
          leagues.map((leagueData, index) => (
            <div key={leagueData.id}>
              <LeagueAccordion
                league={{
                  id: leagueData.league.id,
                  name: leagueData.league.name,
                  country: leagueData.league.country || '',
                  logo: leagueData.league.logo || '',
                  flag: leagueData.league.flag,
                }}
                fixtures={leagueData.fixtures}
                oddsMap={oddsMap}
                defaultOpen={
                  index < 3 || topLeagueIds.includes(leagueData.id)
                }
              />
              {/* Insert 1Win banner every 4 leagues */}
              {(index + 1) % 4 === 0 && index < leagues.length - 1 && (
                <Banner1Win variant="inline" />
              )}
            </div>
          ))
        )}
      </div>

      {/* Sidebar (desktop only) */}
      <aside className="layout-sidebar">
        <div className="sidebar-widget">
          <div className="sidebar-widget-title">Ligas principales</div>
          {leagues
            .filter((l) => topLeagueIds.includes(l.id))
            .slice(0, 8)
            .map((l) => (
              <a key={l.id} href={`/partidos?league=${l.id}`} className="sidebar-league-item">
                <img src={l.league.logo} alt={l.league.name} />
                <span>{l.league.name}</span>
              </a>
            ))}
        </div>

        <Banner1Win variant="full" />
      </aside>
    </div>
  );
}
