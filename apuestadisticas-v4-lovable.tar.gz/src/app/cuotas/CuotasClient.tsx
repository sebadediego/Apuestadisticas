'use client';

import { useState } from 'react';
import Banner1Win from '@/components/Banner1Win';

const AFFILIATE_LINK = 'https://lkpq.cc/b8edf9';

export default function CuotasClient({ fixtures }: { fixtures: any[] }) {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  return (
    <div className="layout-main" style={{ margin: '0 auto' }}>
      <div className="page-header">
        <h1 className="page-title">Cuotas del día</h1>
        <p className="section-subtitle">Cuotas disponibles para todos los partidos de hoy</p>
      </div>

      <Banner1Win variant="odds" />

      {fixtures.length === 0 ? (
        <div className="empty-state">
          <p>No hay cuotas disponibles para hoy</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
          {fixtures.map((fix: any) => {
            const fId = fix.fixture?.id;
            const isExpanded = expandedId === fId;
            const matchWinner = fix.allOdds['Match Winner'] || fix.allOdds[1] || [];
            const overUnder = fix.allOdds['Goals Over/Under'] || fix.allOdds[5] || [];
            const bothScore = fix.allOdds['Both Teams Score'] || fix.allOdds[8] || [];

            return (
              <div key={fId} className="league-group">
                <div
                  className="match-row"
                  onClick={() => setExpandedId(isExpanded ? null : fId)}
                  style={{ cursor: 'pointer' }}
                >
                  <div className="match-teams" style={{ flex: 1 }}>
                    <div className="match-team-line">
                      <img src={fix.teams?.home?.logo} alt="" className="match-team-logo" />
                      <span className="match-team-name">{fix.teams?.home?.name}</span>
                    </div>
                    <div className="match-team-line">
                      <img src={fix.teams?.away?.logo} alt="" className="match-team-logo" />
                      <span className="match-team-name">{fix.teams?.away?.name}</span>
                    </div>
                  </div>

                  <div className="match-odds">
                    {['Home', 'Draw', 'Away'].map((label, i) => {
                      const val = matchWinner.find((v: any) => v.value === label)?.odd;
                      return (
                        <a
                          key={label}
                          href={AFFILIATE_LINK}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="odd-pill"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <span className="odd-pill-label">{['1', 'X', '2'][i]}</span>
                          <span className={`odd-pill-value ${!val ? 'empty' : ''}`}>
                            {val || '—'}
                          </span>
                        </a>
                      );
                    })}
                  </div>
                </div>

                {isExpanded && (
                  <div style={{ padding: '12px 16px', borderTop: '1px solid var(--border-subtle)' }}>
                    {overUnder.length > 0 && (
                      <div style={{ marginBottom: '12px' }}>
                        <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '6px', fontWeight: 600 }}>
                          Goles Over/Under
                        </div>
                        <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
                          {overUnder.map((v: any, i: number) => (
                            <a
                              key={i}
                              href={AFFILIATE_LINK}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="odd-pill"
                            >
                              <span className="odd-pill-label">{v.value}</span>
                              <span className="odd-pill-value">{v.odd}</span>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}

                    {bothScore.length > 0 && (
                      <div>
                        <div style={{ fontSize: '12px', color: 'var(--text-muted)', marginBottom: '6px', fontWeight: 600 }}>
                          Ambos marcan
                        </div>
                        <div style={{ display: 'flex', gap: '4px' }}>
                          {bothScore.map((v: any, i: number) => (
                            <a
                              key={i}
                              href={AFFILIATE_LINK}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="odd-pill"
                            >
                              <span className="odd-pill-label">{v.value}</span>
                              <span className="odd-pill-value">{v.odd}</span>
                            </a>
                          ))}
                        </div>
                      </div>
                    )}

                    <div style={{ marginTop: '12px' }}>
                      <a
                        href={AFFILIATE_LINK}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="banner-1win-cta"
                        style={{ fontSize: '12px', padding: '6px 14px' }}
                      >
                        Ver más mercados en 1Win →
                      </a>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
