import { getFixtures, getOdds } from '@/lib/api-football';
import CuotasClient from './CuotasClient';

function getTodayDate() {
  return new Date().toISOString().split('T')[0];
}

export default async function CuotasPage() {
  const date = getTodayDate();

  let fixtures: any[] = [];
  let oddsMap: Record<number, any> = {};

  try {
    const [fixturesRes, oddsRes] = await Promise.all([
      getFixtures({ date }),
      getOdds({ date }),
    ]);

    fixtures = fixturesRes.response || [];

    const oddsArr = oddsRes.response || []; if (Array.isArray(oddsArr)) {
      for (const item of oddsArr) {
        const fid = item.fixture?.id;
        if (!fid) continue;
        const allMarkets: any = {};
        for (const bk of (item.bookmakers || []).slice(0, 1)) {
          for (const bet of (bk.bets || [])) {
            allMarkets[bet.name || bet.id] = bet.values;
          }
        }
        oddsMap[fid] = allMarkets;
      }
    }
  } catch (e) {
    console.error('Error fetching cuotas:', e);
  }

  // Merge fixtures with their odds
  const fixturesWithOdds = fixtures
    .filter((f: any) => oddsMap[f.fixture?.id])
    .map((f: any) => ({
      ...f,
      allOdds: oddsMap[f.fixture?.id] || {},
    }));

  return <CuotasClient fixtures={fixturesWithOdds} />;
}
